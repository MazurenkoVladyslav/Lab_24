$(() => {
    $("#startButton").click(loadData);
    $("#clearStorageButton").click(clearStorage);
    $("#categoryFilter, #searchTerm, #sortOrder").on("change input", filterAndSortProducts);
    init();
});

const localStorageKey = 'productCards';

const loadData = () => {
    $.ajax({
        type: "get",
        url: "https://dummyjson.com/products?limit=100",
        dataType: "json",
        success: function (data) {
            const { products } = data;
            const formattedProducts = products.map(product => ({
                title: product.title,
                description: product.description,
                category: product.category,
                price: product.price,
                date: new Date().toISOString().split('T')[0],
                image: product.thumbnail
            }));
            localStorage.setItem(localStorageKey, JSON.stringify(formattedProducts));
            productRender(formattedProducts);
            $("#startButton").hide();
        },
        error: function (xhr, status, error) {
            console.error("AJAX Error:", status, error);
        },
    });
}

const productRender = (products) => {
    const container = $("#productList");
    container.empty();

    products.forEach((product) => {
        const pcard = $(`
            <div class="product-card">
                <img src="${product.image}" alt="product image">
                <h3>${product.title}</h3>
                <p>${product.description}</p>
                <p><strong>Категорія:</strong> ${product.category}</p>
                <p><strong>Ціна:</strong> ${product.price} грн</p>
                <p><strong>Дата додавання:</strong> ${product.date}</p>
            </div>
        `);

        container.append(pcard);
    });
};

const clearStorage = () => {
    localStorage.removeItem(localStorageKey);
    console.log('LocalStorage cleared');
    $("#productList").empty();
    $("#startButton").show();
}

const filterAndSortProducts = () => {
    let products = JSON.parse(localStorage.getItem(localStorageKey)) || [];

    const category = $("#categoryFilter").val();
    if (category) {
        products = products.filter(product => product.category === category);
    }

    const search = $("#searchTerm").val().toLowerCase();
    if (search) {
        products = products.filter(product => product.title.toLowerCase().includes(search) || product.description.toLowerCase().includes(search));
    }

    const sort = $("#sortOrder").val();
    products.sort((a, b) => {
        if (sort === 'priceAsc') return a.price - b.price;
        if (sort === 'priceDesc') return b.price - a.price;
        if (sort === 'newest') return new Date(b.date) - new Date(a.date);
        if (sort === 'oldest') return new Date(a.date) - new Date(b.date);
    });

    productRender(products);
}

const init = () => {
    const storedProducts = localStorage.getItem(localStorageKey);
    if (storedProducts) {
        productRender(JSON.parse(storedProducts));
        $("#startButton").hide();
    } else {
        $("#startButton").show();
    }
}
